package battle;

/**
 * This class specifies the special type of sword named as battle.BroadSwords. It is a medium type
 * weapon and can do 6 to 10 point damage when they hit.
 */
public class BroadSwords extends Sword {
  /**
   * This constructs the object of BroadSword class.
   *
   * @param name the name of the sword.
   */
  public BroadSwords(String name) {
    super(name, 6, 10, 3);
  }

  @Override
  public int getMinDamage() {
    return this.minDamage;
  }

  @Override
  public int getMaxDamage() {
    return this.maxDamage;
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public int getId() {
    return this.id;
  }

  @Override
  protected boolean equalsBroadSwords(BroadSwords other) {
    return true;
  }

  @Override
  public boolean equals(Object other) {
    if (other instanceof Sword) {
      Sword sword = (Sword) other;
      return sword.equalsBroadSwords(this);
    }
    return false;
  }

  @Override
  public String toString() {
    return String.format("BroadSwords "
            + "\nname " + name
            + "\nminDamage " + minDamage
            + "\nmaxDamage " + maxDamage
            + "\nid=" + id);
  }

  @Override
  public int hashCode() {
    return 0;
  }
}
