package battle;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * This class is used to test the battle object.
 */
public class BattleTest {
  private Battle battleTest;
  private Player player1;
  private Player player2;

  /**
   * This method is easy and short way of creating instances of a new
   * Battle object.
   *
   * @param num the object of the random generator.
   * @return a new instance of a battle class object
   */
  protected Battle testBattle(ValueGenerator num) {
    return new Battle(new DefinedNumberGenerator());
  }


  @Before
  public void setUp() throws Exception {
    battleTest = testBattle(new DefinedValueGenerator());
    player1 = new Player("Devarsh", new DefinedValueGenerator());
    player2 = new Player("Patel", new DefinedNumberGenerator());
  }

  @Test
  public void requestPlayers() {
    List<Player> playerList;
    assertTrue(battleTest.requestPlayers().get(0) instanceof Player);
    assertTrue(battleTest.requestPlayers().get(1) instanceof Player);
    assertEquals(battleTest.requestPlayers().get(0).getName(), "Devarsh");
    assertEquals(battleTest.requestPlayers().get(1).getName(), "Patel");
  }

  @Test
  public void equipPlayer() {
    battleTest.equipPlayer(player1);
    /* when the player is equipped we calculate striking power, avoidance ability, and effective
    health in  this fuctinon so we would compare all those to check this functions correctly
    or not.*/
    assertEquals(player1.getStrikingPower(), 14);
    assertEquals(player1.getAvoidanceAbility(), 12);
    assertEquals(player1.getEffectiveHealth(), 39);

    /* Now we will test that the player is equipped with correct gears and weapon or not. */
    // to test gears
    assertTrue(player1.getEquippedGear().size() > 0);
    assertTrue(player1.getEquippedGear().size() <= 20);
    for (int i = 0; i < player1.getEquippedGear().size(); i++) {
      assertTrue(player1.getEquippedGear().get(i) instanceof Gear);
    }
    // to test weapons
    assertEquals(player1.getEquippedWeapon().get(0).getName(), "Broad");
  }

  @Test
  public void compareCharisma() {
    assertTrue(battleTest.compareCharisma(player1, player2));
    assertFalse(battleTest.compareCharisma(player2, player1));
  }

  @Test
  public void fight() {
    battleTest.equipPlayer(player1);
    battleTest.equipPlayer(player2);
    Integer[] test = {8, 0};
    assertArrayEquals(battleTest.fight(player1, player2), test);
  }

  @Test
  public void testRandomness() {
    for (int i = 0; i < 1000; i++) {
      Player player1 = new Player("Devarsh", new RandomValueGenerator());
      Player player2 = new Player("Patel", new RandomValueGenerator());
      assertTrue(player1.getStrength() >= 6 && player1.getStrength() <= 18);
      assertTrue(player1.getConstitution() >= 6 && player1.getConstitution() <= 18);
      assertTrue(player1.getDexterity() >= 6 && player1.getDexterity() <= 18);
      assertTrue(player1.getCharisma() >= 6 && player1.getCharisma() <= 18);
      assertTrue(player1.getHealth() >= 24 && player1.getHealth() <= 72);
      player1.equippedGearHelper(new Arena(new RandomValueGenerator()));
      player2.equippedGearHelper(new Arena(new RandomValueGenerator()));
      player1.equipWeapon(new Arena(new RandomValueGenerator()));
//      player1.getEquippedWeapon();
      player2.equipWeapon(new Arena(new RandomValueGenerator()));
      List<Gear> listOfGear = new ArrayList<>();
      int size = listOfGear.size();
      for (int j = 0; j < size; j++) {
        assertTrue(listOfGear.get(i).getEffect() > 0
                && listOfGear.get(i).getEffect() <= 10);
      }
      player1.calculateStrikingPower();
      player2.calculateStrikingPower();
      assertTrue(player1.getStrikingPower() >= 0 && player1.getStrikingPower() <= 128);
      player1.calculateAvoidanceAbility();
      player2.calculateAvoidanceAbility();
      assertTrue(player1.getAvoidanceAbility() >= 0
              && player1.getAvoidanceAbility() <= 148);
      player1.calculateEffectiveHealth();
      player2.calculateEffectiveHealth();
      assertTrue(player1.getEffectiveHealth() >= 0 && player1.getEffectiveHealth() <= 300);
      assertTrue(player1.attack(player2) >= 0 && player1.attack(player2) <= 150);
    }
  }
}