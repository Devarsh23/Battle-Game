package battle;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the class where the main battle takes place. Here the two players are initialized
 * they equip gears from list and, also request weapons from list.
 * After that, a turn taking game starts.
 */
public class Battle {
  private Arena arena;
  ValueGenerator randomNumber;

  /**
   * This constructs the object of the battle class. It takes the object of the random generator
   * as the argument.
   *
   * @param randomNumber the object of the ValueGenerator class.
   */
  public Battle(ValueGenerator randomNumber) {
    this.randomNumber = randomNumber;
    arena = new Arena(this.randomNumber);
  }

  /**
   * This method specifies the players for the battle.
   *
   * @return the list of players in the battle
   */
  public List<Player> requestPlayers() {
    Player player1 = new Player("Devarsh", randomNumber);
    Player player2 = new Player("Patel", randomNumber);
    List<Player> listOfPlayer = new ArrayList<>();
    listOfPlayer.add(player1);
    listOfPlayer.add(player2);
    return listOfPlayer;
  }

  /**
   * In this method the player is equipped with the gears and weapons.
   */
  public Player equipPlayer(Player player) {
    player.equippedGearHelper(arena);
    player.equipWeapon(arena);
    player.calculateStrikingPower();
    player.calculateAvoidanceAbility();
    player.calculateEffectiveHealth();
    return player;
  }


  /**
   * This method specifies the player who possess higher charisma.
   *
   * @param player1 the object of player 1.
   * @param player2 the object of player 2.
   * @return true if {@code p1} has higher charisma than {@code p2}
   */
  public boolean compareCharisma(Player player1, Player player2) {
    return (player1.getEffectiveCharisma() > player2.getEffectiveCharisma());

  }

  /**
   * The fight method refers to how the entire fight is carried out. If a player's striking
   * power exceeds the opponent's avoidance ability, the opponent takes damage and his health is
   * updated correspondingly. Then it's time for the opponent to do the same. This is one of them.
   * This is the first round of the battle.
   *
   * @param player1 Object of Player 1
   * @param player2 Object of Player 2
   * @return an array containing the damage values of the round.
   */
  public Integer[] fight(Player player1, Player player2) {
    Integer[] arr = new Integer[2];
    if (player1.getStrikingPower() > player2.getAvoidanceAbility()) {
      arr[0] = player1.attack(player2);
      player2.modifyHealth(arr[0]);
    } else {
      arr[0] = 0;
    }
    if (player2.getStrikingPower() > player1.getAvoidanceAbility()) {
      arr[1] = player2.attack(player1);
      player1.modifyHealth(arr[1]);
    } else {
      arr[1] = 0;
    }
    return arr;
  }
}
