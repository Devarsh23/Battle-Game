package battle;

/**
 * This class specifies the battle.Flails weapon. It implements the weapon interface.
 * It includes the fields like name of weapon, min and max damage it can make.
 */
public class Flails implements Weapon {
  private String name;
  private int minDamage;
  private int maxDamage;
  private int id;

  /**
   * This constructs the object of the battle.Flails weapon.
   * @param name the name of the flails weapon.
   */

  public Flails(String name) {
    if (name.equals("")) {
      throw new IllegalArgumentException("The name can not be empty");
    }
    this.name = name;
    this.minDamage = 8;
    this.maxDamage = 12;
    this.id = 2;

  }

  @Override
  public int getMinDamage() {
    return this.minDamage;
  }

  @Override
  public int getMaxDamage() {
    return this.maxDamage;
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public int getId() {
    return id;
  }

  @Override
  public String toString() {
    return String.format("Flails "
            + "\nname " + name
            + "\nminDamage=" + minDamage
            + "\nmaxDamage=" + maxDamage
            + "\nid=" + id);
  }
}
