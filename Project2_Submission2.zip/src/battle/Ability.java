package battle;

/**
 * This is the enum class which specifies the categories of the ability a player can possess.
 */

public enum Ability {
  STRENGTH, CONSTITUTION, DEXTERITY, CHARISMA;
}
