package battle;

/**
 * This is the enum class which specify the sizes of the belt available for the player.
 */
public enum BeltSize {
  SMALL, MEDIUM, LARGE;
}
